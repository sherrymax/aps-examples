package com.activiti.extension.bean;

import org.activiti.engine.ManagementService;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.DelegateTask;
import org.activiti.engine.delegate.TaskListener;
//import org.activiti.engine.impl.persistence.entity.JobEntity;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("ProcessTaskListener")
public class ProcessTaskListener implements TaskListener {

	private static final long serialVersionUID = 1L;
	private static Logger logger = LoggerFactory.getLogger(ProcessTaskListener.class);

	@Override
	public void notify(DelegateTask task) {

		System.out.println("*** START OF TASK LISTENER ***");
		DelegateExecution execution = task.getExecution();
		ManagementService managementService = task.getExecution().getEngineServices().getManagementService();
		System.out.println("*** MANAGEMENT SERVICE ***" + managementService);
		System.out.println("*** END OF TASK LISTENER ***");

	}

}
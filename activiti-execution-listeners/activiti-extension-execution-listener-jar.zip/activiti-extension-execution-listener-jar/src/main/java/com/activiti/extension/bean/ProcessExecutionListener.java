package com.activiti.extension.bean;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.ExecutionListener;
import org.activiti.engine.impl.pvm.delegate.ExecutionListenerExecution;

public class ProcessExecutionListener implements ExecutionListener {

	private static final long serialVersionUID = 1L;

	public void notify(ExecutionListenerExecution execution) throws Exception {
		// execution.setVariable("variableSetInExecutionListener", "firstValue");
		// execution.setVariable("eventReceived", execution.getEventName());

		System.out.println("*** Execution Listener Is Started ***");
		System.out.println("*** Event  Received == " + execution.getEventName());
	}

	@Override
	public void notify(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub

		System.out.println("*** DelegateExecution Listener Is Started ***");
		System.out.println("*** DelegateExecution  Received == " + execution.getEventName());

	}

}

package com.activiti.extension.bean;

import java.util.ArrayList;
import java.util.List;
import org.activiti.engine.delegate.DelegateTask;
import org.activiti.engine.delegate.TaskListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

import org.activiti.engine.delegate.Expression;
import com.activiti.domain.runtime.RelatedContent;
import com.activiti.repository.runtime.RelatedContentRepository;
import com.activiti.service.api.UserService;
import com.activiti.service.runtime.RelatedContentService;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import org.activiti.engine.delegate.DelegateExecution;

@Component("copyAttachmentFromChildToParentTaskListener")
public class CopyAttachmentFromChildToParentTaskListener implements TaskListener {

	/**
	 * This task listener copies the "supportingfiles" field's attachments in subprocess/child
	 * process instance to a new attachment field "supportingfiles" in the
	 * parent task.
	 */
	private static final long serialVersionUID = 1L;
	
	private Expression sourceField;
	private Expression targetField;

	private static final Logger log = LoggerFactory.getLogger(CopyAttachmentFromChildToParentTaskListener.class);

	@Autowired
	private UserService userService;

	@Autowired
	private RelatedContentService relatedContentService;

	@Autowired
	private RelatedContentRepository relatedContentRepository;

	

	@Override
	public void notify(DelegateTask delegateTask) {
		List<RelatedContent> relatedContent = new ArrayList<RelatedContent>();
		Page<RelatedContent> page = null;
	    DelegateExecution execution = delegateTask.getExecution();

		String parentProcessInstanceID  = (String)delegateTask.getExecution().getVariable("superProcessInstanceId");
		String childProcessInstanceID  = (String)delegateTask.getProcessInstanceId();
		
		String sourceFieldName = ((String)(sourceField).getValue(execution)).toLowerCase();
		String targetFieldName = ((String)(targetField).getValue(execution)).toLowerCase();

		System.out.println("*** Parent Process Instance ID ***"+parentProcessInstanceID);
		System.out.println("*** Child Process Instance ID ***"+childProcessInstanceID);
		
		System.out.println("*** Source Field ***"+sourceFieldName);
		System.out.println("*** Target Field ***"+targetFieldName);
		
		
		while ((page == null) || (page.hasNext())) {
			page = relatedContentRepository.findAllByProcessInstanceIdAndField((String) delegateTask.getProcessInstanceId(), sourceFieldName, null);
			relatedContent.addAll(page.getContent());
		}
		for (RelatedContent rc : relatedContent) {
			// Create a new related content object in the Parent Process
			RelatedContent newRelatedContentObject = relatedContentService.createRelatedContent(
					userService.getUser(new Long(delegateTask.getAssignee())), rc.getName(), rc.getSource(),
					rc.getSourceId(), delegateTask.getId(), parentProcessInstanceID, targetFieldName,
					rc.getMimeType(), null, 0L);
			
			// Now copy all the existing values from original attachment to the newly created related content
			newRelatedContentObject.setContentStoreId(rc.getContentStoreId());
			newRelatedContentObject.setContentAvailable(rc.isContentAvailable());
			newRelatedContentObject.setContentSize(rc.getContentSize());
			newRelatedContentObject.setRelatedContent(rc.isRelatedContent());
			newRelatedContentObject.setField(targetFieldName);
			
			// Save
			relatedContentRepository.saveAndFlush(newRelatedContentObject);
		}
	}
	
	// @Override
	// public void notify(DelegateTask delegateTask) {
	// log.info("************GOT INTO IT *****************" +
	// delegateTask.getExecution().getProcessInstanceId());
	//
	// String fileName = "OutputPDF.pdf";
	// File file = new File("/tmp/OutputPDF.pdf");
	//
	// try {
	// if
	// (relatedContentRepository.findAllByProcessInstanceIdAndField(delegateTask.getProcessInstanceId(),
	// "supportingfiles", null).getContent().size() == 0) {
	// log.info("creating file: ");
	// FileInputStream fileInputStream = new FileInputStream(file);
	// String taskId = delegateTask.getId();
	// String processId = delegateTask.getProcessInstanceId();
	//
	// RelatedContent newRelatedContentObject =
	// relatedContentService.createRelatedContent(
	// userService.getUser(new Long(delegateTask.getAssignee())), fileName, null,
	// null, taskId,
	// processId, "supportingfiles", "application/pdf", fileInputStream, null);
	// relatedContentRepository.saveAndFlush(newRelatedContentObject);
	// }
	// } catch (FileNotFoundException e) {
	// e.printStackTrace();
	// }
	// }

}
